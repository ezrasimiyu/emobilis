from django.shortcuts import render, HttpResponse
from django.contrib.auth.models import User

# Create your views here.

def HomePage(request):
    return render (request,'homepage.html')


def SignupPage(request):
    if request.method =='POST':
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        email = request.POST.get('email')
        profile = request.POST.get('profile')
        pwd = request.POST.get('pwd')
        confirmpwd = request.POST.get('confirmpwd')

        my_user = User.objects.create_user(username=fname, last_name=lname, email= email,password = pwd)
        my_user.save()
        return HttpResponse ("User has been created successfully!")
        redirect('login')
        #print(username=fname, last_name=lname, email= email,password = pwd, confirmpwd)
    return render (request,'signup.html')

def LoginPage(request):
     return render (request,'login.html') 
