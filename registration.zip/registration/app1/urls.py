

# urlpatterns=[
#     redirect('login')
# ]